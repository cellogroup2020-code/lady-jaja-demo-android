(function(){
  LJ.showSplash();
  if('serviceWorker' in navigator && location.protocol!=='file:'){navigator.serviceWorker.register('sw.js').catch(()=>{})}
  const app=document.getElementById('app');
  let db=LJ.getDB();
  let session=null,currentUser=null,currentOutletId=null,tab='forms';
  let activeFormId=null,activeStartTime=null,activeResponses={},validationErrors={};

  function loadSession(){
    try{session=JSON.parse(sessionStorage.getItem('LJ_EMP_SESSION')||'null')}catch(e){session=null}
    if(session){currentUser=db.users.find(u=>u.id===session.userId)||null;currentOutletId=session.outletId||null}
  }
  function saveSession(){sessionStorage.setItem('LJ_EMP_SESSION',JSON.stringify({userId:currentUser?.id,outletId:currentOutletId}))}
  function logout(){sessionStorage.removeItem('LJ_EMP_SESSION');currentUser=null;currentOutletId=null;activeFormId=null;renderLogin()}

  function renderLogin(error=''){
    app.innerHTML=`<div class="login-shell">
      <section class="login-visual"><div class="login-brand"><img src="assets/logo.png" alt="Lady Jaja"></div><div class="login-claim"><h1>Simple tools.<br>Consistent shifts.</h1><p>BUILT ON EVERYDAY TRUST</p></div></section>
      <section class="login-panel"><div class="login-card"><h2>Employee sign in</h2><p class="lede">Use your Employee ID and PIN to open your Lady Jaja forms.</p>${error?`<div class="error-box">${LJ.esc(error)}</div>`:''}
      <form id="loginForm"><div class="field"><label>Employee ID</label><input class="input" id="employeeId" autocomplete="username" placeholder="e.g. FOH001" required></div><div class="field"><label>PIN</label><input class="input" id="pin" type="password" inputmode="numeric" autocomplete="current-password" placeholder="4-digit PIN" required></div><button class="btn btn-primary full" type="submit">Sign In</button></form>
      <div class="login-note">Lady Jaja Employee App • FOH / BOH</div></div></section></div>`;
    document.getElementById('loginForm').addEventListener('submit',e=>{
      e.preventDefault();db=LJ.getDB();
      const id=document.getElementById('employeeId').value.trim(),pin=document.getElementById('pin').value.trim();
      const user=LJ.userByEmployeeId(db,id);
      if(!user||user.pin!==pin)return renderLogin('Employee ID or PIN is incorrect.');
      if(!['FOH In-Charge','BOH In-Charge'].includes(user.role))return renderLogin('This account belongs to Backoffice. Please use the Manager / Admin portal.');
      currentUser=user;currentOutletId=null;saveSession();renderBranchSelection();
    });
  }

  function renderBranchSelection(){
    db=LJ.getDB();
    const outlets=currentUser.outlets.map(id=>LJ.outletById(db,id)).filter(Boolean);
    app.innerHTML=`<div class="login-shell"><section class="login-visual"><div class="login-brand"><img src="assets/logo.png" alt="Lady Jaja"></div><div class="login-claim"><h1>Select your<br>outlet.</h1><p>${LJ.esc(currentUser.role.toUpperCase())}</p></div></section><section class="login-panel"><div class="login-card"><h2>Good to see you, ${LJ.esc(currentUser.name.split(' ')[0])}</h2><p class="lede">Choose the Lady Jaja outlet you are working in for this session.</p><div class="branch-grid">${outlets.map((o,i)=>`<button class="branch-card" data-outlet="${o.id}"><div class="branch-no">0${i+1}</div><h4>${LJ.esc(o.name)}</h4><div class="small muted">Open this outlet →</div></button>`).join('')}</div><button id="branchLogout" class="btn btn-ghost full" style="margin-top:18px">Sign Out</button></div></section></div>`;
    document.querySelectorAll('.branch-card').forEach(b=>b.addEventListener('click',()=>{currentOutletId=b.dataset.outlet;saveSession();renderApp()}));
    document.getElementById('branchLogout').onclick=logout;
  }

  function topbar(){
    const outlet=LJ.outletById(db,currentOutletId);
    return `<header class="topbar"><div class="brand-lockup"><img src="assets/logo.png"><div><div class="brand-title">Lady Jaja</div><div class="brand-sub">${LJ.esc(outlet?.name||'')}</div></div></div><div class="top-actions"><button class="icon-btn" id="changeOutlet" title="Change outlet">↔</button><div class="user-chip"><div class="avatar">${LJ.initials(currentUser.name)}</div><div class="u-text"><div class="small strong">${LJ.esc(currentUser.name)}</div><div class="small muted">${LJ.esc(currentUser.role)}</div></div></div><button class="icon-btn" id="logoutBtn" title="Sign out">↗</button></div></header>`;
  }
  function greeting(){const h=new Date().getHours();return h<12?'morning':h<18?'afternoon':'evening'}

  function renderApp(){
    db=LJ.getDB();
    if(!currentUser||!currentOutletId)return renderLogin();
    const outlet=LJ.outletById(db,currentOutletId),first=currentUser.name.split(' ')[0];
    app.innerHTML=`<div class="mobile-shell">${topbar()}<main class="employee-main"><section class="hero-card"><div class="hero-kicker">${LJ.esc(currentUser.department)} • ${LJ.esc(outlet.name)}</div><h1>Good ${greeting()}, ${LJ.esc(first)}.</h1><div class="hero-meta"><span class="pill">${LJ.formatDate(LJ.dateKey())}</span><span class="pill">${LJ.esc(currentUser.role)}</span></div></section><div class="employee-tabs"><button class="tab-btn ${tab==='forms'?'active':''}" data-tab="forms">My Forms</button><button class="tab-btn ${tab==='history'?'active':''}" data-tab="history">Submission History</button></div><div id="tabContent"></div></main></div>`;
    document.getElementById('logoutBtn').onclick=logout;
    document.getElementById('changeOutlet').onclick=()=>{currentOutletId=null;saveSession();renderBranchSelection()};
    document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;renderApp()});
    tab==='forms'?renderForms():renderHistory();
  }

  function draftKey(formId){return `${currentUser.id}|${currentOutletId}|${formId}`}
  function getDraft(formId){return db.drafts[draftKey(formId)]||null}
  function todaySubmissions(formId){return db.submissions.filter(s=>s.formId===formId&&s.userId===currentUser.id&&s.outletId===currentOutletId&&s.submissionDate===LJ.dateKey()).sort((a,b)=>new Date(b.submitTime)-new Date(a.submitTime))}
  function formQuestionCount(form){return form.sections.reduce((n,s)=>n+s.questions.length,0)}
  function draftProgress(form,draft){
    if(!draft)return 0;let answered=0,total=0;
    form.sections.forEach(sec=>sec.questions.forEach(q=>{total++;const r=draft.responses?.[q.id];if(r&&((q.type==='photo'&&(r.photos||[]).length)||(!['',null,undefined].includes(r.value))))answered++}));
    return total?Math.round(answered/total*100):0;
  }

  function renderForms(){
    const forms=db.forms.filter(f=>f.published&&f.department===currentUser.department&&f.outlets.includes(currentOutletId));
    const c=document.getElementById('tabContent');
    c.innerHTML=`<div class="section-title"><div><h2>Your forms</h2><p>Demo mode allows repeated submissions so you can test each form as many times as needed.</p></div></div><div class="form-list">${forms.map(f=>{
      const subs=todaySubmissions(f.id),latest=subs[0],draft=getDraft(f.id),pc=draftProgress(f,draft);
      const status=subs.length?`Submitted ${subs.length}× today`:'Pending';
      return `<article class="form-card"><div class="form-icon">${f.category==='Daily Report'?'R':f.category==='Opening Checklist'?'O':'C'}</div><div class="form-card-body"><h3>${LJ.esc(f.name)}</h3><div class="form-meta">${formQuestionCount(f)} items • ${LJ.esc(f.category)}${draft?` • Draft saved`:''}</div>${draft?`<div class="progress-line"><span style="width:${pc}%"></span></div>`:''}</div><div class="form-card-actions"><span class="status ${subs.length?'submitted':'pending'}">${status}</span>${latest?`<button class="btn btn-soft small" data-view-sub="${latest.id}">View latest</button>`:''}<button class="btn btn-primary small" data-open-form="${f.id}">${draft?'Resume Draft':subs.length?'Submit Again':'Open'}</button></div></article>`;
    }).join('')}</div>`;
    c.querySelectorAll('[data-open-form]').forEach(b=>b.onclick=()=>openForm(b.dataset.openForm));
    c.querySelectorAll('[data-view-sub]').forEach(b=>b.onclick=()=>showSubmission(b.dataset.viewSub));
  }

  function renderHistory(){
    const subs=db.submissions.filter(s=>s.userId===currentUser.id).sort((a,b)=>new Date(b.submitTime)-new Date(a.submitTime));
    const c=document.getElementById('tabContent');
    c.innerHTML=`<div class="section-title"><div><h2>Submission history</h2><p>All forms submitted from your account, including repeat demo tests.</p></div></div>${subs.length?subs.map(s=>{const f=LJ.formById(db,s.formId);return `<article class="history-card"><div class="history-top"><div><div class="history-title">${LJ.esc(f?.name||'Form')}</div><div class="history-meta">${LJ.esc(s.outletName)} • ${LJ.formatDateTime(s.submitTime)}</div></div><button class="btn btn-soft small" data-view-sub="${s.id}">View</button></div></article>`}).join(''):`<div class="history-card muted">No submissions yet.</div>`}`;
    c.querySelectorAll('[data-view-sub]').forEach(b=>b.onclick=()=>showSubmission(b.dataset.viewSub));
  }

  function openForm(formId){
    db=LJ.getDB();const form=LJ.formById(db,formId);if(!form)return;
    activeFormId=formId;validationErrors={};
    const draft=getDraft(formId);
    activeStartTime=draft?.startTime||new Date().toISOString();
    activeResponses=LJ.clone(draft?.responses||{});
    renderFormPage();window.scrollTo({top:0,behavior:'smooth'});
  }
  function responseFor(qid){if(!activeResponses[qid])activeResponses[qid]={value:'',comment:'',photos:[]};return activeResponses[qid]}
  function answeredCount(form){let total=0,answered=0;form.sections.forEach(s=>s.questions.forEach(q=>{total++;const r=responseFor(q.id);const ok=q.type==='photo'?(r.photos||[]).length:r.value!==''&&r.value!==null&&r.value!==undefined;if(ok)answered++}));return {answered,total,pct:total?Math.round(answered/total*100):0}}

  function renderFormPage(){
    const form=LJ.formById(db,activeFormId),outlet=LJ.outletById(db,currentOutletId),progress=answeredCount(form);
    app.innerHTML=`<div class="mobile-shell">${topbar()}<main class="form-page"><button class="btn btn-ghost" id="backForms" style="margin-bottom:12px">← Back</button><section class="form-head"><div class="eyebrow">${LJ.esc(form.department)} • ${LJ.esc(form.category)}</div><h1>${LJ.esc(form.name)}</h1><div class="form-head-meta"><span>${LJ.esc(outlet.name)}</span><span>•</span><span>Started ${LJ.formatDateTime(activeStartTime)}</span></div><div class="form-progress"><div><span>${progress.answered} of ${progress.total} answered</span><strong>${progress.pct}%</strong></div><div class="progress-line"><span style="width:${progress.pct}%"></span></div></div></section>${form.sections.map(sec=>`<section class="form-section"><div class="form-section-title"><h3>${LJ.esc(sec.title)}</h3></div>${sec.questions.map(renderQuestion).join('')}</section>`).join('')}<div class="form-footer"><button class="btn btn-ghost" id="saveDraft">Save Draft</button><button class="btn btn-primary" id="submitForm">Submit Form</button></div></main></div>`;
    document.getElementById('logoutBtn').onclick=logout;
    document.getElementById('changeOutlet').onclick=()=>LJ.toast('Finish or save this form before changing outlet.');
    document.getElementById('backForms').onclick=()=>{tab='forms';renderApp()};
    bindQuestionEvents();
    document.getElementById('saveDraft').onclick=saveDraft;
    document.getElementById('submitForm').onclick=submitForm;
  }

  function renderQuestion(q){
    const r=responseFor(q.id),err=validationErrors[q.id];let control='';
    if(q.type==='yesno'||q.type==='yesnona'){
      const opts=q.type==='yesno'?['Yes','No']:['Yes','No','N/A'];control=`<div class="choice-row">${opts.map(o=>`<button type="button" class="choice-btn ${r.value===o?'selected':''}" data-choice-q="${q.id}" data-value="${o}">${o}</button>`).join('')}</div>`;
    }else if(q.type==='multiple'){
      control=`<div class="choice-row">${(q.options||[]).map(o=>`<button type="button" class="choice-btn ${r.value===o?'selected':''}" data-choice-q="${q.id}" data-value="${LJ.esc(o)}">${LJ.esc(o)}</button>`).join('')}</div>`;
    }else if(q.type==='shorttext'){
      control=`<input class="input answer-control" data-input-q="${q.id}" value="${LJ.esc(r.value)}" placeholder="${LJ.esc(q.placeholder||'Enter response')}" ${q.maxLength?`maxlength="${q.maxLength}"`:''}>${q.maxLength?`<div class="field-hint">Maximum ${q.maxLength} characters</div>`:''}`;
    }else if(q.type==='longtext'){
      control=`<textarea class="textarea answer-control" data-input-q="${q.id}" placeholder="${LJ.esc(q.placeholder||'Enter details')}" ${q.maxLength?`maxlength="${q.maxLength}"`:''}>${LJ.esc(r.value)}</textarea>${q.maxLength?`<div class="field-hint">Maximum ${q.maxLength} characters</div>`:''}`;
    }else if(q.type==='number'){
      control=`<input class="input answer-control" data-input-q="${q.id}" type="number" value="${LJ.esc(r.value)}" ${q.min!==''&&q.min!==undefined?`min="${q.min}"`:''} ${q.max!==''&&q.max!==undefined?`max="${q.max}"`:''} ${q.step?`step="${q.step}"`:''} placeholder="${LJ.esc(q.placeholder||'Enter number')}"><div class="field-hint">${numberHint(q)}</div>`;
    }else if(q.type==='date'){
      control=`<input class="input answer-control" data-input-q="${q.id}" type="date" value="${LJ.esc(r.value)}" ${q.minDate?`min="${q.minDate}"`:''} ${q.maxDate?`max="${q.maxDate}"`:''}><div class="field-hint">Format: YYYY-MM-DD${q.minDate?` • From ${LJ.esc(q.minDate)}`:''}${q.maxDate?` • To ${LJ.esc(q.maxDate)}`:''}</div>`;
    }else if(q.type==='time'){
      control=`<input class="input answer-control" data-input-q="${q.id}" type="time" value="${LJ.esc(r.value)}" ${q.minTime?`min="${q.minTime}"`:''} ${q.maxTime?`max="${q.maxTime}"`:''}><div class="field-hint">24-hour format: HH:MM${q.minTime?` • From ${LJ.esc(q.minTime)}`:''}${q.maxTime?` • To ${LJ.esc(q.maxTime)}`:''}</div>`;
    }else if(q.type==='rating'){
      const scale=Number(q.scale)||5;control=`<div class="rating">${Array.from({length:scale},(_,i)=>i+1).map(n=>`<button type="button" class="${Number(r.value)===n?'selected':''}" data-choice-q="${q.id}" data-value="${n}">${n}</button>`).join('')}</div><div class="field-hint">Rate from 1 to ${scale}</div>`;
    }else if(q.type==='photo'){
      const max=Number(q.maxPhotos)||3;control=`<div class="photo-box"><label class="photo-trigger">📷 Open Camera<input type="file" accept="image/*" capture="environment" multiple data-photo-q="${q.id}"></label><div class="small muted" style="margin-top:8px">Camera only • up to ${max} photo${max===1?'':'s'}</div>${(r.photos||[]).length?`<div class="photo-previews">${r.photos.map((p,i)=>`<div class="photo-thumb"><img src="${p}" alt="Evidence ${i+1}"><button type="button" class="photo-remove" data-remove-photo="${q.id}|${i}" title="Remove photo">×</button></div>`).join('')}</div>`:''}</div>`;
    }
    const comment=(q.requireCommentOnNo&&r.value==='No')?`<div class="conditional-comment"><div class="small strong" style="margin-bottom:7px">Comment required because “No” was selected.</div><textarea class="textarea answer-control" data-comment-q="${q.id}" placeholder="Explain the issue">${LJ.esc(r.comment||'')}</textarea></div>`:'';
    return `<div class="form-question" id="q_${q.id}"><div class="q-label">${LJ.esc(q.label)} ${q.required?'<span class="req">*</span>':''}</div>${control}${comment}${err?`<div class="validation">${LJ.esc(err)}</div>`:''}</div>`;
  }
  function numberHint(q){
    const parts=[];if(q.min!==''&&q.min!==undefined)parts.push(`Minimum ${q.min}`);if(q.max!==''&&q.max!==undefined)parts.push(`Maximum ${q.max}`);if(q.step)parts.push(`Step ${q.step}`);return parts.length?parts.join(' • '):'Numeric answer';
  }

  function bindQuestionEvents(){
    document.querySelectorAll('[data-choice-q]').forEach(b=>b.onclick=()=>{responseFor(b.dataset.choiceQ).value=b.dataset.value;delete validationErrors[b.dataset.choiceQ];renderFormPage()});
    document.querySelectorAll('[data-input-q]').forEach(el=>el.addEventListener('input',()=>{responseFor(el.dataset.inputQ).value=el.value;delete validationErrors[el.dataset.inputQ]}));
    document.querySelectorAll('[data-comment-q]').forEach(el=>el.addEventListener('input',()=>{responseFor(el.dataset.commentQ).comment=el.value;delete validationErrors[el.dataset.commentQ]}));
    document.querySelectorAll('[data-photo-q]').forEach(el=>el.addEventListener('change',async()=>{
      const qid=el.dataset.photoQ,form=LJ.formById(db,activeFormId),q=form.sections.flatMap(s=>s.questions).find(x=>x.id===qid),max=Number(q.maxPhotos)||3;
      const existing=responseFor(qid).photos||[],remaining=Math.max(0,max-existing.length),files=[...el.files].slice(0,remaining),arr=[];
      for(const f of files)arr.push(await compressImage(f));
      responseFor(qid).photos=[...existing,...arr].slice(0,max);responseFor(qid).value=responseFor(qid).photos.length?'Photos':'';delete validationErrors[qid];renderFormPage();
    }));
    document.querySelectorAll('[data-remove-photo]').forEach(b=>b.onclick=()=>{const [qid,idx]=b.dataset.removePhoto.split('|');const r=responseFor(qid);r.photos.splice(Number(idx),1);r.value=r.photos.length?'Photos':'';renderFormPage()});
  }
  function compressImage(file){return new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const max=900;let w=img.width,h=img.height;const scale=Math.min(1,max/Math.max(w,h));w=Math.round(w*scale);h=Math.round(h*scale);const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h);resolve(c.toDataURL('image/jpeg',.72))};img.src=reader.result};reader.readAsDataURL(file)})}

  function saveDraft(){db=LJ.getDB();db.drafts[draftKey(activeFormId)]={formId:activeFormId,userId:currentUser.id,outletId:currentOutletId,startTime:activeStartTime,updatedAt:new Date().toISOString(),responses:LJ.clone(activeResponses)};LJ.saveDB(db);LJ.toast('Draft saved.')}
  function validateForm(){
    validationErrors={};const form=LJ.formById(db,activeFormId);
    form.sections.forEach(sec=>sec.questions.forEach(q=>{
      const r=responseFor(q.id),empty=q.type==='photo'?!(r.photos||[]).length:(r.value===''||r.value===null||r.value===undefined);
      if(q.required&&empty)validationErrors[q.id]='This item is required.';
      if(q.requireCommentOnNo&&r.value==='No'&&!String(r.comment||'').trim())validationErrors[q.id]='Please add a comment for this “No” response.';
      if(q.type==='number'&&!empty){const n=Number(r.value);if(Number.isNaN(n))validationErrors[q.id]='Enter a valid number.';else if(q.min!==''&&q.min!==undefined&&n<Number(q.min))validationErrors[q.id]=`Minimum accepted value is ${q.min}.`;else if(q.max!==''&&q.max!==undefined&&n>Number(q.max))validationErrors[q.id]=`Maximum accepted value is ${q.max}.`}
      if(q.type==='date'&&!empty){if(q.minDate&&r.value<q.minDate)validationErrors[q.id]=`Earliest accepted date is ${q.minDate}.`;if(q.maxDate&&r.value>q.maxDate)validationErrors[q.id]=`Latest accepted date is ${q.maxDate}.`}
      if(q.type==='time'&&!empty){if(q.minTime&&r.value<q.minTime)validationErrors[q.id]=`Earliest accepted time is ${q.minTime}.`;if(q.maxTime&&r.value>q.maxTime)validationErrors[q.id]=`Latest accepted time is ${q.maxTime}.`}
    }));
    return Object.keys(validationErrors).length===0;
  }
  function submitForm(){
    db=LJ.getDB();if(!validateForm()){renderFormPage();const first=Object.keys(validationErrors)[0];document.getElementById('q_'+first)?.scrollIntoView({behavior:'smooth',block:'center'});LJ.toast('Please complete the required items.');return}
    const form=LJ.formById(db,activeFormId),outlet=LJ.outletById(db,currentOutletId),responses=form.sections.flatMap(sec=>sec.questions).map(q=>({questionId:q.id,value:responseFor(q.id).value,comment:responseFor(q.id).comment||'',photos:responseFor(q.id).photos||[]}));
    db.submissions.push({id:LJ.uid('sub'),formId:form.id,userId:currentUser.id,employeeId:currentUser.employeeId,employeeName:currentUser.name,role:currentUser.role,department:currentUser.department,outletId:outlet.id,outletName:outlet.name,submissionDate:LJ.dateKey(),startTime:activeStartTime,submitTime:new Date().toISOString(),responses});
    delete db.drafts[draftKey(activeFormId)];LJ.saveDB(db);activeFormId=null;activeResponses={};validationErrors={};tab='forms';renderApp();LJ.toast('Form submitted. You can submit another demo test anytime.');
  }

  function submissionContext(sub){
    const f=LJ.formById(db,sub.formId),qMap={};f?.sections.forEach(sec=>sec.questions.forEach(q=>qMap[q.id]={...q,section:sec.title}));return {f,qMap};
  }
  function photoRecords(sub){const {qMap}=submissionContext(sub),out=[];(sub.responses||[]).forEach(r=>(r.photos||[]).forEach((p,i)=>out.push({data:p,q:qMap[r.questionId],index:i+1})));return out}
  function downloadAllPhotos(sub){
    const photos=photoRecords(sub);if(!photos.length)return LJ.toast('No photos attached to this submission.');
    const base=LJ.safeFilename(`${sub.submissionDate}_${sub.outletName}_${sub.employeeName}`);photos.forEach((x,i)=>setTimeout(()=>LJ.downloadDataUrl(`${base}_Photo_${String(i+1).padStart(2,'0')}.${LJ.dataUrlExtension(x.data)}`,x.data),i*180));LJ.toast(`${photos.length} photo download${photos.length===1?'':'s'} started.`);
  }
  function exportSubmissionExcel(sub){
    const {f,qMap}=submissionContext(sub),rows=(sub.responses||[]).map(r=>{const q=qMap[r.questionId];return `<tr><td>${LJ.esc(q?.section||'')}</td><td>${LJ.esc(q?.label||'')}</td><td>${LJ.esc(r.value||((r.photos||[]).length?`${r.photos.length} photo(s)`:'—'))}</td><td>${LJ.esc(r.comment||'')}</td><td>${(r.photos||[]).length}</td></tr>`}).join('');
    const html=`<html><head><meta charset="utf-8"></head><body><h2>Lady Jaja - ${LJ.esc(f?.name||'Submission')}</h2><table border="1"><tr><th>Outlet</th><td>${LJ.esc(sub.outletName)}</td><th>Employee</th><td>${LJ.esc(sub.employeeName)}</td></tr><tr><th>Employee ID</th><td>${LJ.esc(sub.employeeId)}</td><th>Department</th><td>${LJ.esc(sub.department)}</td></tr><tr><th>Start</th><td>${LJ.esc(LJ.formatDateTime(sub.startTime))}</td><th>Submitted</th><td>${LJ.esc(LJ.formatDateTime(sub.submitTime))}</td></tr></table><br><table border="1"><tr><th>Section</th><th>Question</th><th>Answer</th><th>Comment</th><th>Photos</th></tr>${rows}</table></body></html>`;
    LJ.download(`${LJ.safeFilename(f?.name||'Lady_Jaja_Submission')}_${sub.submissionDate}.xls`,html,'application/vnd.ms-excel');
  }
  function exportSubmissionPDF(sub){
    const {f,qMap}=submissionContext(sub),w=window.open('','_blank');if(!w)return LJ.toast('Please allow pop-ups to export PDF.');let current='',body='';
    (sub.responses||[]).forEach(r=>{const q=qMap[r.questionId];if(!q)return;if(q.section!==current){current=q.section;body+=`<h3>${LJ.esc(current)}</h3>`}body+=`<div class="row"><div class="q">${LJ.esc(q.label)}</div><div>${LJ.esc(r.value||((r.photos||[]).length?'Photo evidence':'—'))}</div>${r.comment?`<div class="comment"><b>Comment:</b> ${LJ.esc(r.comment)}</div>`:''}${(r.photos||[]).length?`<div class="photos">${r.photos.map(p=>`<img src="${p}">`).join('')}</div>`:''}</div>`});
    w.document.write(`<html><head><title>${LJ.esc(f?.name||'Lady Jaja')}</title><style>body{font-family:Arial,sans-serif;padding:30px;color:#111}h1{color:#E74605;margin-bottom:4px}h3{color:#E74605;border-bottom:1px solid #eee;padding-bottom:6px;margin-top:24px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:8px;background:#FBF0E3;padding:14px;border-radius:12px}.row{padding:12px 0;border-bottom:1px solid #eee;font-size:12px}.q{font-weight:700;margin-bottom:5px}.comment{margin-top:5px}.photos{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.photos img{width:145px;height:110px;object-fit:cover;border:1px solid #ddd;border-radius:8px}@media print{button{display:none}}</style></head><body><h1>Lady Jaja</h1><h2>${LJ.esc(f?.name||'Submission')}</h2><div class="meta"><div><b>Outlet:</b> ${LJ.esc(sub.outletName)}</div><div><b>Employee:</b> ${LJ.esc(sub.employeeName)} (${LJ.esc(sub.employeeId)})</div><div><b>Department:</b> ${LJ.esc(sub.department)}</div><div><b>Submitted:</b> ${LJ.esc(LJ.formatDateTime(sub.submitTime))}</div></div>${body}<script>setTimeout(()=>window.print(),500)<\/script></body></html>`);w.document.close();
  }

  function showSubmission(id){
    db=LJ.getDB();const sub=db.submissions.find(s=>s.id===id);if(!sub)return;const {f,qMap}=submissionContext(sub);let current='',body='';
    (sub.responses||[]).forEach(r=>{const q=qMap[r.questionId];if(!q)return;if(q.section!==current){current=q.section;body+=`<div class="answer-section"><h4>${LJ.esc(current)}</h4></div>`}body+=`<div class="answer-row"><div class="question">${LJ.esc(q.label)}</div><div class="answer">${LJ.esc(r.value||((r.photos||[]).length?'Photo evidence':'—'))}${r.comment?`<div class="small" style="margin-top:5px"><strong>Comment:</strong> ${LJ.esc(r.comment)}</div>`:''}${(r.photos||[]).length?`<div class="evidence-grid">${r.photos.map((p,i)=>`<figure class="evidence-item"><img src="${p}"><button class="photo-download" type="button" data-download-photo="${r.questionId}|${i}">↓ Download</button></figure>`).join('')}</div>`:''}</div></div>`});
    const photos=photoRecords(sub),modal=document.createElement('div');modal.className='modal';modal.innerHTML=`<div class="modal-card"><div class="modal-head"><div><div class="small muted">${LJ.esc(sub.department)} • ${LJ.esc(f?.category||'Form')}</div><h3 style="margin-top:3px">${LJ.esc(f?.name||'Submission')}</h3></div><button class="icon-btn" data-close>✕</button></div><div class="modal-body"><div class="submission-meta-grid"><div class="meta-box"><span>Outlet</span><strong>${LJ.esc(sub.outletName)}</strong></div><div class="meta-box"><span>Submitted</span><strong>${LJ.formatDateTime(sub.submitTime)}</strong></div><div class="meta-box"><span>Employee</span><strong>${LJ.esc(sub.employeeName)}</strong></div></div>${body}</div><div class="modal-foot modal-foot-split"><div class="toolbar"><button class="btn btn-soft" id="employeeExportXls">Export Excel</button><button class="btn btn-soft" id="employeeExportPdf">Export PDF</button>${photos.length?`<button class="btn btn-soft" id="employeeDownloadPhotos">Download Photos (${photos.length})</button>`:''}</div><button class="btn btn-primary" data-close>Done</button></div></div>`;document.body.appendChild(modal);LJ.bindModal(modal);
    document.getElementById('employeeExportXls').onclick=()=>exportSubmissionExcel(sub);document.getElementById('employeeExportPdf').onclick=()=>exportSubmissionPDF(sub);if(photos.length)document.getElementById('employeeDownloadPhotos').onclick=()=>downloadAllPhotos(sub);
    modal.querySelectorAll('[data-download-photo]').forEach(b=>b.onclick=()=>{const [qid,idx]=b.dataset.downloadPhoto.split('|'),r=sub.responses.find(x=>x.questionId===qid),p=r?.photos?.[Number(idx)];if(p)LJ.downloadDataUrl(`${LJ.safeFilename(f?.name)}_${qid}_${Number(idx)+1}.${LJ.dataUrlExtension(p)}`,p)});
  }

  loadSession();
  if(currentUser){if(currentOutletId&&currentUser.outlets.includes(currentOutletId))renderApp();else renderBranchSelection()}else renderLogin();
})();
